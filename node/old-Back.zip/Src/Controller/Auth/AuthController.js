exports.login = function(req, res) {
    res.send('NOT IMPLEMENTED: Site Home Page');
};